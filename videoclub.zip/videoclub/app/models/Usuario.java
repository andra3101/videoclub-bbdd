package models;

import play.db.jpa.Model;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Usuario extends Model {

    private String nom;
    private String pwd;
    private int num;
    private int edat;
    private int dni;



    public Usuario(String nom, String pwd, int num, int edat, int dni) {
        this.nom = nom;
        this.pwd = pwd;
        this.num = num;
        this.edat = edat;
        this.dni = dni;
    }

    public Usuario() {
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPwd() {
        return pwd;
    }
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public int getNum() {
        return num;
    }
    public void setNum(int num) {
        this.num = num;
    }

    public int getEdat() {
        return edat;
    }
    public void setEdat(int edat) {
        this.edat = edat;
    }

    public int getDni() {
        return dni;
    }
    public void setDni(int dni) {
        this.dni = dni;
    }
}