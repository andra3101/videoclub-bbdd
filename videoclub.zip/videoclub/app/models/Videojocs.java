package models;

import play.db.jpa.Model;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Videojocs extends Model {

    Private String nom;
    Private String genere;
    Private String autor;
    Private int any;

    Public Videojocs (String nom, String genere, String autor, int any) {
        this.nom = nom;
        this.genere = genere;
        this.any = any;
    }

    @ManyToOne
    public Usuario usuario;
    public String getNom() { return nom; }
    public void setNom(String nom) {this.nom = nom;}

    public String getNom() { return nom; }
    public void setGenere(String genere) { this.genere = genere; }

    public int getAny() { return any; }
    public void setAny(int Any) { this.any = any; }

}



}