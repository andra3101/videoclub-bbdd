package models;

import play.db.jpa.Model;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Cançons extends Model {

    Private String nom;
    Private String genere;
    Private String autor;
    Private int any;

    Public Cançons (String nom, String genere, String autor, int any) {
        this.nom = nom;
        this.genere = genere;
        this.autor = autor;
        this.any = any;
    }
    @ManyToOne
    public Usuario usuario;

    public String getNom() { return nom; }
    public void setNom(String nom) {this.nom = nom;}

    public String getNom() { return nom; }
    public void setGenere(String genere) { this.genere = genere; }

    public String getAutor() { return autor; }
    public void setAutor(String Autor) { this.autor= autor; }

    public int getAny() { return any; }
    public void setAny(int Any) { this.any = any; }

}



}