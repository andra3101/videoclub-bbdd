package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Application extends Controller {

    public static void index() {
        render();


    }

        public static void afegirUsuari(String nom, int pwd){

            Usuario p = usuario.find("byNom", nom).first();

            if (p==null){

                new Propietari(nom,pwd).save();

                renderText("Usuari donat d'alta");

            }
            else{

                renderText("Nom usuari ja existeix");

            }

        }
    }

